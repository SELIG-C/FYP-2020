figure
plot(controlSignal.Time, controlSignal.Data(:,1))
hold on
yyaxis right
plot(outputSignal.Time, outputSignal.Data(:,1))